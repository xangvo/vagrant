export PATH=$PATH:/sbin:/usr/sbin:~/bin
